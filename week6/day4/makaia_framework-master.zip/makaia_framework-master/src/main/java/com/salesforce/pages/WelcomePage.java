package com.salesforce.pages;

public class WelcomePage {

	public WelcomePage clickAppLauncher() {
		
		return this;
	}
	
	
	public AppLauncherWindow clickViewAll() {
		
		return new AppLauncherWindow();
	}
	
}
