package com.salesforce.pages;

public class AppLauncherWindow {

	
	public HomePage clickSales() {
	
		return new HomePage();
	}
	
}
