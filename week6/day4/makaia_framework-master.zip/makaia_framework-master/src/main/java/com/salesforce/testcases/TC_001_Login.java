package com.salesforce.testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.framework.testng.api.base.ProjectSpecificMethods;
import com.salesforce.pages.LoginPage;

public class TC_001_Login extends ProjectSpecificMethods {

	
	@BeforeTest
	public void setData() {
		testcaseName = "LoginTC";
		testDescription ="Postivie Scenario";
		authors = "Gokul";
		category ="Regression";
	}
	
	@Test
	public void runLogin() {
		new LoginPage()
		.enterUsername("gokul.sekar@testleaf.com")
		.enterPassword("Leaf@123")
		.clickLogin();
	}
	
	
	
	
}
