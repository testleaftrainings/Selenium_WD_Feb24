package com.salesforce.pages;

public class HomePage {

	public LeadsPage clickLeadsTab() {
	
		return new LeadsPage();
	}
	
}
