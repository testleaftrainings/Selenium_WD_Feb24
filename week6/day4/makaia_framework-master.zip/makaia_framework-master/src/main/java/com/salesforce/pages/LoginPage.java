package com.salesforce.pages;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage enterUsername(String uname) {
		clearAndType(locateElement(Locators.ID, "username"), uname);
		reportStep("Username entered sucessfully", "pass");
		return this;
	}
	
	public LoginPage enterPassword(String pwd) {
		clearAndType(locateElement(Locators.ID, "password"), pwd);
		reportStep("Password entered successfully", "pass");
		return this;
	}
	
	public WelcomePage clickLogin() {
		click(locateElement(Locators.ID, "Login"));
		reportStep("Login clicked successfully", "pass");
		return new WelcomePage();
	}
	
	
	
}
