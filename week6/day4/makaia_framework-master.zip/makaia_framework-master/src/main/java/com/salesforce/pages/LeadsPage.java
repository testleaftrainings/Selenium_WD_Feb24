package com.salesforce.pages;

public class LeadsPage {

	
	public CreateLeadPage clickNew() {
		
		return new CreateLeadPage();
	}
	
}
