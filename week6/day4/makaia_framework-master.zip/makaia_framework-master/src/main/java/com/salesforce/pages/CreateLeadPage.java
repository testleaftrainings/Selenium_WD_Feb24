package com.salesforce.pages;

public class CreateLeadPage {

	public CreateLeadPage chooseSalution() {
		
		return this;
	}
	
	public CreateLeadPage enterLastName() {
		
		return this;
	}
	
	public CreateLeadPage clickSave() {
		
		return this;
	}
	
}
