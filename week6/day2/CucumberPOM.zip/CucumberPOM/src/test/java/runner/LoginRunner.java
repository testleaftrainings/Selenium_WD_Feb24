package runner;

import base.ProjectSpecificMethod;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;


@CucumberOptions(features = "src/test/java/features",
				 glue ="stepDefinition",
				 publish = true,
				 monochrome = true)
public class LoginRunner extends ProjectSpecificMethod {

}
