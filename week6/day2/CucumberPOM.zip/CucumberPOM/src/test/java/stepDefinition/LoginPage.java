package stepDefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends ProjectSpecificMethod{

	
	public LoginPage() {

	}
	
	public LoginPage(ChromeDriver driver) {
		this.driver = driver;  // gobal driver = local driver, Assigning local driver value into the global driver varibale
	}

	@Given("Enter the username")
	public LoginPage enterUsername() {
		System.out.println("This is from enter user name method "+driver);
		driver.findElement(By.id("username")).sendKeys("demosalesmanager");
		//Option 1
//		LoginPage lp = new LoginPage(); // dataType varibale = value;
//		return lp;
		//Option 2 
//		return new LoginPage();
		//option 3
		return this;
	}
	
	@Given("Enter the password")
	public LoginPage enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
		return this;
	}
	
	@When("Click on the login button")
	public WelcomePage clickLoginBtn() {
		driver.findElement(By.className("decorativeSubmit")).click();
//		WelcomePage wp = new WelcomePage();
//		return wp;
		
		return new WelcomePage(driver);
	}
	
}
