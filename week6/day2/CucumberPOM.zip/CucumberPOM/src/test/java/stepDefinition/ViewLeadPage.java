package stepDefinition;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod {

	public ViewLeadPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public void retriveLeadID() {
		
	}
	
	public void clickDuplicateLeadBtn() {
		
	}
	
	public void clickEditLeadBtn() {
		
	}
	
	public void clickDeleteLeadBtn() {
		
	}
	
}
