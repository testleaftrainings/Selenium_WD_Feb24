package testcases;

import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import stepDefinition.LoginPage;

public class TC_001_LoginTC extends ProjectSpecificMethod{

	@Test
	public void runLogin() {
		new LoginPage(driver)
		.enterUsername()
		.enterPassword()
		.clickLoginBtn();
	}
	
}
