package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethod;

public class ViewLeadPage extends ProjectSpecificMethod {

	

	public void retriveLeadID() {
		String leadId = getDriver().findElement(By.id("viewLead_companyName_sp")).getText();
		System.out.println(leadId);
	}
	
	public void clickDuplicateLeadBtn() {
		
	}
	
	public void clickEditLeadBtn() {
		
	}
	
	public void clickDeleteLeadBtn() {
		
	}
	
}
