package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class TC_002_CreateLeadTC extends ProjectSpecificMethod {

	@Test
	public void runCreateLead() throws IOException {
		new LoginPage()
		.enterUsername()
		.enterPassword()
		.clickLoginBtn()
		.clickCrmsfa()
		.clickLeadsTab()
		.clickCreateLeadLink()
		.enterCompanyName("Testleaf")
		.enterFirstName("Gokul")
		.enterLastname("Sekar")
		.enterPhno("99")
		.clickCreateLeadBtn()
		.retriveLeadID();
		
		
		
	}
	
	
	
	@BeforeTest
	public void setData() {
		testcaseName = "Create lead testcase";
		testcaseDescription = "Create lead testcase with positive functionality";
		authorName = "Gokul";
		categoryName = "Regression";
	}
}
